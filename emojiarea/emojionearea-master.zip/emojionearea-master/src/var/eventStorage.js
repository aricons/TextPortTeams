define([], function() {
    return {};
});